# Contributing

Fork and submit Pull Requests for additions. Create Issues for bugs, broken
scripts, or suggestsions.

## Questions? 

You can open a [new Issue](https://github.com/her/uosteam/issues/new) or if it's easier, send me an email! You can find my [contact information here](http://berkley.io).
